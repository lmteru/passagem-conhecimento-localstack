import json

print('loading')

def lambda_handler(event, context):
    return 'Hello World!'